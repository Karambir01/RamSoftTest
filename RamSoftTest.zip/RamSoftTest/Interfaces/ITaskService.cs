﻿
using RamSoftTest.Models;

namespace RamSoftTest.Interfaces
{
    public interface ITaskService
    {
        Task<TaskItem> CreateTaskAsync(TaskItem dto);
        Task<TaskItem> GetTaskByIdAsync(int id);
        Task<bool> UpdateTaskAsync(int id, TaskItem dto);
        Task<bool> DeleteTaskAsync(int id);
        Task<List<TaskItem>> GetTasksByColumnAsync(int columnId);
        Task<bool> MoveTaskAsync(int taskId, int newColumnId);

    }
}
