﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RamSoftTest.Data;
using RamSoftTest.Models;
using System;

namespace RamSoftTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ColumnsController : ControllerBase
    {
        private readonly TaskBoardContext _context;

        public ColumnsController(TaskBoardContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> Create(Column column)
        {
            _context.Columns.Add(column);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetAll), new { id = column.Id }, column);
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var columns = await _context.Columns.Include(c => c.Tasks).ToListAsync();
            return Ok(columns);
        }
    }

}
