﻿using Microsoft.AspNetCore.Mvc;
using RamSoftTest.Interfaces;
using RamSoftTest.Models;


namespace RamSoftTest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        private readonly ITaskService _service;

        public TasksController(ITaskService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<IActionResult> Create(TaskItem task)
        {
            var created = await _service.CreateTaskAsync(task);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var task = await _service.GetTaskByIdAsync(id);
            return task == null ? NotFound() : Ok(task);
        }

        [HttpGet("column/{columnId}")]
        public async Task<IActionResult> GetByColumn(int columnId)
        {
            var tasks = await _service.GetTasksByColumnAsync(columnId);
            return Ok(tasks);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, TaskItem updated)
        {
            var result = await _service.UpdateTaskAsync(id, updated);
            return result ? NoContent() : NotFound();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var result = await _service.DeleteTaskAsync(id);
            return result ? NoContent() : NotFound();
        }
    }


}