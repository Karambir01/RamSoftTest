﻿using Microsoft.EntityFrameworkCore;
using RamSoftTest.Models;
using System.Collections.Generic;

namespace RamSoftTest.Data
{
    public class TaskBoardContext : DbContext
    {
        public TaskBoardContext(DbContextOptions<TaskBoardContext> options) : base(options) { }

        public DbSet<TaskItem> Tasks { get; set; }
        public DbSet<Column> Columns { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed Columns
            modelBuilder.Entity<Column>().HasData(
                new Column { Id = 1, Name = "To Do" },
                new Column { Id = 2, Name = "In Progress" },
                new Column { Id = 3, Name = "Done" }
            );
        }
    }

}

