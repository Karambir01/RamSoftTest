﻿using Microsoft.EntityFrameworkCore;
using RamSoftTest.Data;
using RamSoftTest.Interfaces;
using RamSoftTest.Models;

namespace RamSoftTest.Services
{

    public class TaskService : ITaskService
    {
        private readonly TaskBoardContext _context;

        public TaskService(TaskBoardContext context)
        {
            _context = context;
        }

        public async Task<TaskItem> CreateTaskAsync(TaskItem dto)
        {
            var task = new TaskItem
            {
                Name = dto.Name,
                Description = dto.Description,
                Deadline = dto.Deadline,
                ColumnId = dto.ColumnId,
                IsFavorite = dto.IsFavorite
            };
            _context.Tasks.Add(task);
            await _context.SaveChangesAsync();
            return task;
        }

        public async Task<TaskItem> GetTaskByIdAsync(int id) =>
            await _context.Tasks.Include(t => t.Column).FirstOrDefaultAsync(t => t.Id == id);

        public async Task<bool> UpdateTaskAsync(int id, TaskItem dto)
        {
            var task = await _context.Tasks.FindAsync(id);
            if (task == null) return false;
            task.Name = dto.Name;
            task.Description = dto.Description;
            task.Deadline = dto.Deadline;
            task.IsFavorite = dto.IsFavorite;
            task.ColumnId = dto.ColumnId;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteTaskAsync(int id)
        {
            var task = await _context.Tasks.FindAsync(id);
            if (task == null) return false;
            _context.Tasks.Remove(task);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<TaskItem>> GetTasksByColumnAsync(int columnId)
        {
            return await _context.Tasks
                .Where(t => t.ColumnId == columnId)
                .OrderByDescending(t => t.IsFavorite)
                .ThenBy(t => t.Name)
                .ToListAsync();
        }

        public async Task<bool> MoveTaskAsync(int taskId, int newColumnId)
        {
            var task = await _context.Tasks.FindAsync(taskId);
            if (task == null) return false;

            var targetColumn = await _context.Columns.FindAsync(newColumnId);
            if (targetColumn == null) return false;

            task.ColumnId = newColumnId;
            await _context.SaveChangesAsync();
            return true;
        }
    }

}
