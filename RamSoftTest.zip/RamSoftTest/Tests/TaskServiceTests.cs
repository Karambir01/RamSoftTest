﻿using Microsoft.EntityFrameworkCore;
using RamSoftTest.Data;
using RamSoftTest.Models;
using RamSoftTest.Services;
using System;
using Xunit;

namespace RamSoftTest.Tests
{
    public class TaskServiceTests
    {
        private readonly TaskBoardContext _context;
        private readonly TaskService _service;

        public TaskServiceTests()
        {
            var options = new DbContextOptionsBuilder<TaskBoardContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // unique per test class
            .Options;

            _context = new TaskBoardContext(options);

            // Seed with a column
            _context.Columns.Add(new Column { Id = 1, Name = "ToDo" });
            _context.SaveChanges();

            _service = new TaskService(_context);
        }

        [Fact]
        public async Task CreateTaskAsync_ShouldAddTask()
        {
            var task = new TaskItem
            {
                Name = "Task 1",
                Description = "Test Description",
                Deadline = DateTime.UtcNow.AddDays(1),
                ColumnId = 1
            };

            var created = await _service.CreateTaskAsync(task);

            Assert.NotNull(created);
            Assert.Equal("Task 1", created.Name);
            Assert.Equal(1, await _context.Tasks.CountAsync());
        }

        [Fact]
        public async Task GetTaskByIdAsync_ShouldReturnTask()
        {
            var task = new TaskItem
            {
                Name = "Fetch Task",
                Description = "Test",
                ColumnId = 1
            };
            _context.Tasks.Add(task);
            await _context.SaveChangesAsync();

            var result = await _service.GetTaskByIdAsync(task.Id);

            Assert.NotNull(result);
            Assert.Equal(task.Name, result!.Name);
        }

        [Fact]
        public async Task UpdateTaskAsync_ShouldModifyTask()
        {
            var task = new TaskItem
            {
                Name = "Original Title",
                Description = "Desc",
                ColumnId = 1
            };
            _context.Tasks.Add(task);
            await _context.SaveChangesAsync();

            var updated = new TaskItem
            {
                Name = "Updated Title",
                Description = "Updated Desc",
                Deadline = DateTime.UtcNow.AddDays(2),
                IsFavorite = true,
                ColumnId = 1
            };

            var result = await _service.UpdateTaskAsync(task.Id, updated);
            var updatedTask = await _context.Tasks.FindAsync(task.Id);

            Assert.True(result);
            Assert.Equal("Updated Title", updatedTask!.Name);
            Assert.True(updatedTask.IsFavorite);
        }

        [Fact]
        public async Task UpdateTaskAsync_ShouldReturnFalse_IfNotFound()
        {
            var updated = new TaskItem { Name = "X", Description = "X", ColumnId = 1 };
            var result = await _service.UpdateTaskAsync(999, updated);

            Assert.False(result);
        }

        [Fact]
        public async Task DeleteTaskAsync_ShouldRemoveTask()
        {
            var task = new TaskItem { Name = "Delete Me", ColumnId = 1, Description= "Delete Me" };
            _context.Tasks.Add(task);
            await _context.SaveChangesAsync();

            var result = await _service.DeleteTaskAsync(task.Id);

            Assert.True(result);
            Assert.Empty(_context.Tasks);
        }

        [Fact]
        public async Task DeleteTaskAsync_ShouldReturnFalse_IfNotFound()
        {
            var result = await _service.DeleteTaskAsync(12345);
            Assert.False(result);
        }

        [Fact]
        public async Task GetTasksByColumnAsync_ShouldReturnSortedTasks_WithFavoritesOnTop()
        {
            _context.Tasks.AddRange(
                new TaskItem { Name = "Beta", IsFavorite = false, ColumnId = 1,Description="Beta" },
                new TaskItem { Name = "Alpha", IsFavorite = true, ColumnId = 1 , Description = "Alpha" },
                new TaskItem { Name = "Zeta", IsFavorite = false, ColumnId = 1, Description = "Zeta" }
            );
            await _context.SaveChangesAsync();

            var results = await _service.GetTasksByColumnAsync(1);

            Assert.Equal(3, results.Count);
            Assert.Equal("Alpha", results[0].Name); // Favorite first
            Assert.Equal("Beta", results[1].Name);  // Alphabetical
            Assert.Equal("Zeta", results[2].Name);
        }
    }

}
